This data set consists of an additional 350 stories with questions and
answers. There are 4 questions for each story, so a total of 1400
question/answer pairs. 

The use of this data is COMPLETELY OPTIONAL! This data set is not
drawn from the same source as the official development set or test
sets, so these stories and questions may be a bit different in both
style and substance. You should expect that Test Set #1 and Test Set
#2 will be more similar to the development set. However, you are free
to use these additional 350 stories and answer keys if you wish, for
example as additional training data for a machine learning system or
as additional development texts to help you improve the performance of
your system. There are definitely many interesting QA pairs in this
data that further illustrate the challenges for computational question
answering systems!
